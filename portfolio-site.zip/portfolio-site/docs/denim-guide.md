# Denim Sponsorship Proposal

Our goal is to secure a denim sponsorship to make materials available to every student. By partnering with local mills, we hope to reduce costs and allow for experimentation without financial barriers. Denim remains one of the most versatile and sustainable textiles for our projects.